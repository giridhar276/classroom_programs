class ExpectedElementError(Exception):
    pass

class WaitForElementError(Exception):
	pass
