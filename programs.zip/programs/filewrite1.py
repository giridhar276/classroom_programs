

fobj = open("data.txt","w")

for val in range(501,400,-2):
    fobj.write(str(val) + "\n")

fobj.close()