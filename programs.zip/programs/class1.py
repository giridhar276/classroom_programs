
# class contains attriutes and functions
# class is the blueprint of the program
# object is an instance of the class
# self is an instance of the object

class Employee:
    def getInfo(self,name,age):
        self.name = name
        self.age = age

    def displayInfo(self):
        print("Name :",self.name)
        print("Age  :", self.age)
 
        
 # creating object to the class Employee       
emp1 = Employee()
emp1.getInfo("Ram",26) 
emp1.displayInfo()
emp2 = Employee()
emp2.getInfo("Ram",26) 
emp2.displayInfo()
    
    