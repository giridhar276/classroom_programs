# working with list

alist = [10,20,30,40,50,60]

print(alist)

print(alist[0])
print(alist[0:5])
print(alist[::-1])    # display in reverse order
print(alist[::])
print(alist[::3])

# + is used for concatenation
blist = [70,80]

output = alist + blist + [100,110]

print(output)

alist[0] = 1000

print("After modifying :", alist)