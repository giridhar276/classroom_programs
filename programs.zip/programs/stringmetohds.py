name = "python programming"
print("Length of the string :", len(name))
print(name.capitalize())
print(name.upper())
print(name.lower())
print(name.center(30))
print(name.center(30,"*"))
print(name)   # string is immutable (unchangable)
print(name.split(" "))   # will return the list
print(name.isupper())
print(name.islower())
print(name.isalpha())
print(name.isalnum())
print(name.count("p"))
print(name.count("pro"))
print(name.replace("python","scala"))
print(name.find("zyt"))  # will return -1 if not FOUND
print(name.find("gra"))  # will return index number if existin