from openpyxl.workbook import Workbook
import time

wb = Workbook()
ws1 = wb.active
ws1 = wb.worksheets[0]
ws1.title = 'Unix'
 
ws2 = wb.create_sheet()
ws2.title = 'linux'

ws3 = wb.create_sheet()
ws3.title = 'hadoop'

# Save the file
filename = time.strftime("%d_%b_%Y.xlsx")
wb.save(filename)