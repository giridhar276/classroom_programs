atup = (10,20,30,40,50,60)

# diplaying tuple elements
print(atup)
print(atup[0:4])

atup[0] = 10000

print("After modifying :", atup)