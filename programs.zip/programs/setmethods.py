
print("Length :", len(aset))

print(list(range(1,10)))
print(tuple(range(1,10)))
print(list(range(1,10,2)))
print(list(range(2,10,2)))
print(list(range(10,0,-1)))
print(list(range(10)))

print(id(10))
print(id("hello"))
val = 10
print(type(val))
aval = 3.4
print(type(aval))

print(isinstance(3,int))

print(isinstance(3,float))

alist = [10,20,45,1]
print(max(alist))
print(min(alist))
print(sum(alist))

print(list(zip(alist,[0,1,2,3])))
### combining two lists
first = [10,20,30]
second = ["perl","unix","shell"]
print(list(zip(first,second)))




