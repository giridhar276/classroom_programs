# reading the file line by line
# fobj called as file handler or cursor
fobj = open("languages.txt","r")
for line in fobj:
    # strip will remove whitespace at the end
    line = line.strip()
    print(line)

     