


def add(x,y):
    getsum = x + y
    return getsum


def main():
    x = input("Enter first number:")
    y = input("Enter second number:")
    z = add(x,y)
    print(z)
    


main()