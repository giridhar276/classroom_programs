import requests
from bs4 import BeautifulSoup
page = requests.get("https://www.w3schools.com/")
print(page.status_code)

soup = BeautifulSoup(str(page.text), 'html.parser')

for link in soup.find_all('a'):
    print(link.get('href'))


