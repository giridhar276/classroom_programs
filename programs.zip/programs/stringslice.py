aname = 'python programming'
# syntax:  string[start:stop:step]
print(aname[0])
print(aname[1])
print(aname[0:4])
print(aname[0:12])
print(aname[3:8])
print(aname[::])
print(aname[::2])
print(aname[0:18:2])
print(aname[-1])
print(aname[-6:-2])
print(aname[::-1])
print(aname[0::4])
# concatenation 
first = "python"
second = "programming"
output = first + ' ' + second
print(output)

print(first + '  ' + second)


