# fixed arguments
def display(first,second):
    print(first)
    print(second)

display(10,20)
