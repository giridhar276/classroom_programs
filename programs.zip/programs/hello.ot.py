# this is single line comment

'''
val = 10

print(val)
print(10,20,30,40)
print(34.5,45.5,4,5)
print("The values are :", 10,20,30)
'''