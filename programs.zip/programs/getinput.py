




name = input("Enter any name :")

print("Your name is:", name)