
book   = {"chap1":10 ,"chap2":20 ,"chap3":30 ,"chap1":1000 }

print(book)

print(book["chap1"])   #10


book["chap5"] = 50
book["chap6"] = [10,20,30]
print(book)

 