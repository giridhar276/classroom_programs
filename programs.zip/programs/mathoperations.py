import math

print(math.floor(34.9))

print(math.tan(2))

print(math.log(4))


