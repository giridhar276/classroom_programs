#string can be defined in single quotes or double quotes or triple quotes.

aname = 'python programming'
bname ="unix shell scripting"
cname = '''java language'''
dname = """scala programming"""

print("Language :", aname)

print(bname,cname)

print("languages are :", aname,dname)
print()
print()
