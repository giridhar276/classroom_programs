alist = [10,20,30]
print("Length of the list :", len(alist))
# add single object to the list
alist.append(40)
alist.append(50)
alist.append(60)
print("After appending :", alist)
# add set of elements ( iterable ) to the list)
alist.extend([70,80,90])
print("After extending :", alist)

getcount = alist.count(10)
print("count :", getcount)
# remove elments
alist.pop()   ### will remove the last element by default
print("After removing :", alist)
alist.pop(2)
print("After removing :", alist)   # 2nd element will be removed

alist.remove(40)    # delete the element directly withoug index
print("Afte modifications :", alist)


alist.sort()
print(alist)

alist.reverse()
print(alist)