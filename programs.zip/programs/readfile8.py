

import csv
# file object
fobj = open("realestate.csv","r")
# converting into csv object
reader = csv.reader(fobj)
for line in reader:
    print(line)

fobj.close()
