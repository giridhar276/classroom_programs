


import urllib.request as r

r.urlretrieve("http://spatialkeydocs.s3.amazonaws.com/FL_insurance_sample.csv.zip","FL_insurance_sample.csv.zip")