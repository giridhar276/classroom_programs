# using constructors
class Employee:
    ''' this is the documentation of the employee'''
    def __init__(self,name,age):
        self.name = name
        self.age = age

    def displayInfo(self):
        ''' this is the documentation of displayinfo()'''
        print("Name :",self.name)
        print("Age  :", self.age)       
 # creating object to the class Employee       
emp1 = Employee("Ram",26) 
emp1.displayInfo()
 
emp2 = Employee("Venkat",29) 
emp2.displayInfo()
print(Employee.__doc__)
print(emp1.displayInfo.__doc__)
