#method1
fobj = open("languages.txt","r")
# display the file in list format
print(fobj.readlines())
fobj.close()


## method3
fobj = open("languages.txt","r")
# will display the file in string format
print(fobj.read())
fobj.close()
