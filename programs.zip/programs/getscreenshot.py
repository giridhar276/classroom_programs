from PIL import ImageGrab
import time
  


for val in range(1,10):
    # grab the image
    im = ImageGrab.grab()
    time.sleep(5)
    screenshot = time.strftime("%Y%m%d-%H%M%S" + str(val))
         
        # new filename
    screenshot = screenshot + ".jpg"
    print(screenshot)
        # save the screenshot in current directory
    im.save(screenshot)