for val in range(1,11):
    print(val)
#using string
name = "python"
for char in name:
    print(char)
# iterate list
alist = [10,20,30]
for item in alist:
    print(item)    
# iterate tuple
atup = ("unix","scala","hadoop")
for item in atup:
    print(item)    
# using dictionary
adict  = {"chap1":10 ,"chap2":20}
for item in adict:
    print(item)
    print(adict[item])    
    