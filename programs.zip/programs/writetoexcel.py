from openpyxl import Workbook
import os
import time
wb = Workbook()

# grab the active worksheet
ws = wb.active


for file in os.listdir():
    ws.append([file])


# Save the file
filename = time.strftime("%d_%b_%Y.xlsx")
wb.save(filename)