import pymysql

db =pymysql.connect(host ='localhost', port = 3306, user = 'root', password ='india@123',database ="wellfargo")

cursor = db.cursor()


#query = "insert into employee values('{}','{}')".format("amit","singh")

#cursor.execute(query)
query = "select * from employee"
cursor.execute(query)
print("firstname lastname")
print("------------------")
for record in cursor.fetchall():
    print(record[0],"   ", record[1])

db.commit()


db.close()