

a = 10
b = 20

if a < b:
    print("Inside if condition")
    print("A is largest")
else:
    print("In else condition")
    print("B is largest")
    
print("Outside if-else part")
    
    
    
    