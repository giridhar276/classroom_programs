book   = {"chap1":10 ,"chap2":20 ,"chap3":30 }
#book.clear()
print(book)
# display ONLY keys
print(book.keys())
# display ONLY values
print(book.values())
# display all key-value pairs  ( items)
print(book.items())
# add key-value pair
book["chap4"] = 40
print(book)
#print(book["chap5"])
print(book.get("chap5",50))  
book1 = {'chap6':60}
# combining both the dictionaries
book.update(book1)    # updating book1 to book
# pop
book.pop("chap1")    # chap1-10 will be removed from dictionary
print(book)

