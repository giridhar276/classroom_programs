
# If file is not existing.. file will be created
# if file already exists... file content will be erased
#  C:\\Users\\abridge\\Desktop\\flatfiles\\info.txt
#C:/Users/abridge/Desktop/flatfiles/info.txt                         

fobj = open("info.txt","w")

fobj.write("python programming\n")
fobj.write("scala programming\n")

fobj.writelines(["python","unix"])
fobj.close()