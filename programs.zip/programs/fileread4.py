try:
    with  open("languages.txt","r") as fobj:
        for line in fobj:
            # strip will remove whitespace at the end
            line = line.strip()
            print(line)            
    val = int(input("Enter any value:"))
    print(val)
except FileNotFoundError  as error:
    print("File not found.. please check")
    print("system error :", error)
except ValueError as error:
    print("Invalid input")
    print("system error :", error)    
except TypeError as error:
    print("Invalid operation")
    print("system error :", error)
except Exception as error:
    print("Unknown error found")
    print("system error :", error)
    
    
    
    